<!DOCTYPE HTML>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
