<?php

return [

    'views' => [

        'builder' => 'infyom.generator-builder.builder',

        'field-template' => 'infyom.generator-builder.field-template'
    ]
];